import { User, UserRole } from '../types';

// المستخدمين الافتراضيين
export const defaultUsers: User[] = [
  {
    id: '1',
    username: 'admin',
    password: '10',
    role: 'admin',
    permissions: {
      canViewSales: true,
      canMakeSales: true,
      canDeleteSales: true,
      canManageUsers: true,
      canViewReports: true,
    },
  },
  {
    id: '2',
    username: 'writer',
    password: 'writer',
    role: 'writer',
    permissions: {
      canViewSales: true,
      canMakeSales: true,
      canDeleteSales: false,
      canManageUsers: false,
      canViewReports: true,
    },
  },
  {
    id: '3',
    username: 'user',
    password: '22',
    role: 'user',
    permissions: {
      canViewSales: false,
      canMakeSales: true,
      canDeleteSales: false,
      canManageUsers: false,
      canViewReports: false,
    },
  },
];

export function getUsers(): User[] {
  const stored = localStorage.getItem('users');
  return stored ? JSON.parse(stored) : defaultUsers;
}

export function saveUsers(users: User[]) {
  localStorage.setItem('users', JSON.stringify(users));
}

export function authenticateUser(username: string, password: string): User | null {
  const users = getUsers();
  const user = users.find(
    (u) => u.username === username && u.password === password
  );
  return user || null;
}

export function getCurrentUser(): User | null {
  const stored = localStorage.getItem('currentUser');
  return stored ? JSON.parse(stored) : null;
}

export function setCurrentUser(user: User | null) {
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } else {
    localStorage.removeItem('currentUser');
  }
}

export function logout() {
  setCurrentUser(null);
}

export function hasPermission(user: User | null, permission: keyof User['permissions']): boolean {
  return user ? user.permissions[permission] : false;
}
