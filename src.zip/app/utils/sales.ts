import { Sale } from '../types';

export function getSales(): Sale[] {
  const stored = localStorage.getItem('sales');
  return stored ? JSON.parse(stored) : [];
}

export function saveSale(sale: Sale) {
  const sales = getSales();
  sales.push(sale);
  localStorage.setItem('sales', JSON.stringify(sales));
}

export function deleteSale(saleId: string) {
  const sales = getSales();
  const filtered = sales.filter((s) => s.id !== saleId);
  localStorage.setItem('sales', JSON.stringify(filtered));
}

export function getTodaySales(): Sale[] {
  const sales = getSales();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return sales.filter((sale) => {
    const saleDate = new Date(sale.timestamp);
    saleDate.setHours(0, 0, 0, 0);
    return saleDate.getTime() === today.getTime();
  });
}

export function generateInvoiceNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `INV-${year}${month}${day}-${random}`;
}

export function calculateDailyStats(sales: Sale[]) {
  const totalSales = sales.reduce((sum, sale) => sum + sale.total, 0);
  const totalTransactions = sales.length;
  const paymentMethods = {
    cash: sales.filter((s) => s.paymentMethod === 'cash').length,
    card: sales.filter((s) => s.paymentMethod === 'card').length,
    wallet: sales.filter((s) => s.paymentMethod === 'wallet').length,
  };
  
  return {
    totalSales,
    totalTransactions,
    paymentMethods,
    averageTransaction: totalTransactions > 0 ? totalSales / totalTransactions : 0,
  };
}
