import { useState, useEffect } from 'react';
import { CupSoda, LogOut, User as UserIcon, BarChart3 } from 'lucide-react';
import { CategoryTabs } from './components/CategoryTabs';
import { ProductGrid } from './components/ProductGrid';
import { SalesBasket } from './components/SalesBasket';
import { LoginScreen } from './components/LoginScreen';
import { PaymentDialog } from './components/PaymentDialog';
import { SalesHistory } from './components/SalesHistory';
import { Button } from './components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Product, CartItem, User, PaymentMethod, Sale } from './types';
import { getCurrentUser, logout, hasPermission } from './utils/auth';
import { saveSale, generateInvoiceNumber } from './utils/sales';
import { printInvoice } from './components/InvoicePrint';

const products: Product[] = [
  // عصائر طبيعية
  { id: '1', name: 'عصير برتقال', price: 15, category: 'natural', image: 'https://images.unsplash.com/photo-1641659735894-45046caad624?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmFuZ2UlMjBqdWljZSUyMGdsYXNzfGVufDF8fHx8MTc2NzA5NzQ1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '2', name: 'عصير رمان', price: 20, category: 'natural', image: 'https://images.unsplash.com/photo-1663955706695-de874fa93c4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb21lZ3JhbmF0ZSUyMGp1aWNlfGVufDF8fHx8MTc2NzAxMjg2Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '3', name: 'عصير أناناس', price: 18, category: 'natural', image: 'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5lYXBwbGUlMjBqdWljZXxlbnwxfHx8fDE3NjcxMTI1NTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '4', name: 'عصير بطيخ', price: 12, category: 'natural', image: 'https://images.unsplash.com/photo-1683531658992-b78c311900a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcm1lbG9uJTIwanVpY2V8ZW58MXx8fHwxNjcxMTI1NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  
  // سموذي
  { id: '5', name: 'سموذي مانجو', price: 25, category: 'smoothie', image: 'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMHNtb290aGllfGVufDF8fHx8MTc2NzExMjU1NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '6', name: 'سموذي فراولة', price: 22, category: 'smoothie', image: 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJhd2JlcnJ5JTIwanVpY2V8ZW58MXx8fHwxNjcxMTI1NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '7', name: 'سموذي توت مشكل', price: 28, category: 'smoothie', image: 'https://images.unsplash.com/photo-1600718374662-0483d2b9da44?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaXhlZCUyMGJlcnJ5JTIwc21vb3RoaWV8ZW58MXx8fHwxNjcxMTI1NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '8', name: 'سموذي أفوكادو', price: 30, category: 'smoothie', image: 'https://images.unsplash.com/photo-1622704430673-59c152a9991c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdm9jYWRvJTIwc21vb3RoaWV8ZW58MXx8fHwxNjcwODI4NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  
  // مشروبات خاصة
  { id: '9', name: 'كوكتيل استوائي', price: 32, category: 'special', image: 'https://images.unsplash.com/photo-1664993119473-013502f1e3f8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGZydWl0JTIwanVpY2V8ZW58MXx8fHwxNjcxMTI1NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '10', name: 'ليمون نعناع', price: 15, category: 'special', image: 'https://images.unsplash.com/photo-1610378833220-9e374e37856b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZW1vbiUyMG1pbnQlMjBqdWljZXxlbnwxfHx8fDE3NjcxMTI1NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '11', name: 'عصير جزر', price: 16, category: 'special', image: 'https://images.unsplash.com/photo-1556764900-78b59cf886af?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJyb3QlMjBqdWljZXxlbnwxfHx8fDE3NjcxMTI1NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
  { id: '12', name: 'سموذي كيوي', price: 24, category: 'special', image: 'https://images.unsplash.com/photo-1647988215507-aceeab5d57c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraXdpJTIwc21vb3RoaWV8ZW58MXx8fHwxNzY3MTEyNTU3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral' },
];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
    }
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setCart([]);
  };

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      
      return [...prevCart, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setShowPaymentDialog(true);
  };

  const handlePaymentConfirm = (paymentMethod: PaymentMethod) => {
    if (!user) return;

    const sale: Sale = {
      id: Date.now().toString(),
      items: cart,
      total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      paymentMethod,
      userId: user.id,
      userName: user.username,
      timestamp: Date.now(),
      invoiceNumber: generateInvoiceNumber(),
    };

    // Save sale
    saveSale(sale);

    // Print invoice
    printInvoice(sale);

    // Clear cart and close dialog
    setCart([]);
    setShowPaymentDialog(false);
    setRefreshKey(prev => prev + 1);

    // Success message
    setTimeout(() => {
      alert('تمت عملية البيع بنجاح! ✓');
    }, 100);
  };

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  // Show login screen if not logged in
  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  const canViewSales = hasPermission(user, 'canViewSales');

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-orange-100">
        <div className="max-w-[1800px] mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-orange-500 to-yellow-500 p-2 rounded-lg">
              <CupSoda className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl text-gray-900">نقاط البيع - متجر العصائر</h1>
              <p className="text-sm text-gray-500">إدارة المبيعات</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-lg">
              <UserIcon className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-900">{user.username}</span>
              <span className="text-xs bg-orange-500 text-white px-2 py-0.5 rounded">
                {user.role}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-[1800px] mx-auto p-6">
        {canViewSales ? (
          <Tabs defaultValue="sales" className="space-y-6">
            <TabsList className="bg-white border border-gray-200">
              <TabsTrigger value="sales" className="gap-2">
                <CupSoda className="w-4 h-4" />
                نقاط البيع
              </TabsTrigger>
              <TabsTrigger value="history" className="gap-2">
                <BarChart3 className="w-4 h-4" />
                سجل المبيعات
              </TabsTrigger>
            </TabsList>

            <TabsContent value="sales" className="mt-0">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Products Section */}
                <div className="lg:col-span-2">
                  <div className="bg-white rounded-xl shadow-sm p-6">
                    <CategoryTabs
                      selectedCategory={selectedCategory}
                      onSelectCategory={setSelectedCategory}
                    />
                    
                    <ProductGrid
                      products={filteredProducts}
                      onAddToCart={addToCart}
                    />
                  </div>
                </div>

                {/* Sales Basket */}
                <div className="lg:col-span-1">
                  <SalesBasket
                    cart={cart}
                    onUpdateQuantity={updateQuantity}
                    onRemoveItem={removeFromCart}
                    onClearCart={clearCart}
                    onCheckout={handleCheckout}
                    total={total}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-0">
              <SalesHistory key={refreshKey} user={user} />
            </TabsContent>
          </Tabs>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Products Section */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <CategoryTabs
                  selectedCategory={selectedCategory}
                  onSelectCategory={setSelectedCategory}
                />
                
                <ProductGrid
                  products={filteredProducts}
                  onAddToCart={addToCart}
                />
              </div>
            </div>

            {/* Sales Basket */}
            <div className="lg:col-span-1">
              <SalesBasket
                cart={cart}
                onUpdateQuantity={updateQuantity}
                onRemoveItem={removeFromCart}
                onClearCart={clearCart}
                onCheckout={handleCheckout}
                total={total}
              />
            </div>
          </div>
        )}
      </div>

      {/* Payment Dialog */}
      <PaymentDialog
        open={showPaymentDialog}
        onClose={() => setShowPaymentDialog(false)}
        total={total}
        onConfirm={handlePaymentConfirm}
      />
    </div>
  );
}
