import { Apple, Blend, Sparkles } from 'lucide-react';
import { Button } from './ui/button';

interface CategoryTabsProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

const categories = [
  { id: 'all', name: 'الكل', icon: Sparkles, color: 'from-purple-500 to-pink-500' },
  { id: 'natural', name: 'عصائر طبيعية', icon: Apple, color: 'from-green-500 to-emerald-500' },
  { id: 'smoothie', name: 'سموذي', icon: Blend, color: 'from-orange-500 to-yellow-500' },
  { id: 'special', name: 'مشروبات خاصة', icon: Sparkles, color: 'from-blue-500 to-cyan-500' },
];

export function CategoryTabs({ selectedCategory, onSelectCategory }: CategoryTabsProps) {
  return (
    <div className="mb-6">
      <h2 className="text-lg text-gray-900 mb-4">التصنيفات</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {categories.map((category) => {
          const Icon = category.icon;
          const isSelected = selectedCategory === category.id;
          
          return (
            <Button
              key={category.id}
              onClick={() => onSelectCategory(category.id)}
              variant={isSelected ? "default" : "outline"}
              className={`
                h-auto py-4 flex flex-col items-center gap-2 relative overflow-hidden
                ${isSelected 
                  ? `bg-gradient-to-br ${category.color} text-white border-0 shadow-lg` 
                  : 'bg-white hover:bg-gray-50 border-gray-200'
                }
              `}
            >
              <Icon className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-gray-600'}`} />
              <span className={`text-sm ${isSelected ? 'text-white' : 'text-gray-700'}`}>
                {category.name}
              </span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
