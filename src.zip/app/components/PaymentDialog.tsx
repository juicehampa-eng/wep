import { useState } from 'react';
import { CreditCard, Wallet, Banknote, X } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { PaymentMethod } from '../types';

interface PaymentDialogProps {
  open: boolean;
  onClose: () => void;
  total: number;
  onConfirm: (method: PaymentMethod) => void;
}

const paymentMethods = [
  {
    id: 'cash' as PaymentMethod,
    name: 'نقدي',
    icon: Banknote,
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 'card' as PaymentMethod,
    name: 'بطاقة',
    icon: CreditCard,
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'wallet' as PaymentMethod,
    name: 'محفظة إلكترونية',
    icon: Wallet,
    color: 'from-purple-500 to-pink-500',
  },
];

export function PaymentDialog({ open, onClose, total, onConfirm }: PaymentDialogProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);

  const handleConfirm = () => {
    if (selectedMethod) {
      onConfirm(selectedMethod);
      setSelectedMethod(null);
    }
  };

  const handleClose = () => {
    setSelectedMethod(null);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>اختر طريقة الدفع</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Total */}
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg p-4 text-center border border-orange-100">
            <p className="text-sm text-gray-600 mb-1">المبلغ المطلوب</p>
            <p className="text-3xl text-orange-600">{total.toFixed(2)} ريال</p>
          </div>

          {/* Payment Methods */}
          <div className="space-y-3">
            {paymentMethods.map((method) => {
              const Icon = method.icon;
              const isSelected = selectedMethod === method.id;

              return (
                <button
                  key={method.id}
                  onClick={() => setSelectedMethod(method.id)}
                  className={`
                    w-full p-4 rounded-lg border-2 transition-all
                    ${
                      isSelected
                        ? `border-orange-500 bg-gradient-to-r ${method.color} text-white shadow-lg scale-105`
                        : 'border-gray-200 bg-white hover:border-orange-300 hover:shadow-md'
                    }
                  `}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`
                      p-2 rounded-lg
                      ${isSelected ? 'bg-white/20' : 'bg-gray-100'}
                    `}
                    >
                      <Icon
                        className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-gray-600'}`}
                      />
                    </div>
                    <span className={`text-lg ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                      {method.name}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              variant="outline"
              onClick={handleClose}
              className="flex-1"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!selectedMethod}
              className="flex-1 bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white disabled:opacity-50"
            >
              تأكيد الدفع
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
