import { Minus, Plus, Trash2, ShoppingCart, CreditCard } from 'lucide-react';
import { CartItem } from '../types';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';

interface SalesBasketProps {
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onCheckout: () => void;
  total: number;
}

export function SalesBasket({
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onCheckout,
  total,
}: SalesBasketProps) {
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    onCheckout();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm sticky top-6">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-orange-500 to-yellow-500 p-2 rounded-lg">
              <ShoppingCart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg text-gray-900">سلة المبيعات</h2>
              <p className="text-xs text-gray-500">{itemCount} صنف</p>
            </div>
          </div>
          
          {cart.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearCart}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Cart Items */}
      <ScrollArea className="h-[400px]">
        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
            <div className="bg-gray-100 p-4 rounded-full mb-3">
              <ShoppingCart className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-sm text-gray-500">السلة فارغة</p>
            <p className="text-xs text-gray-400 mt-1">قم بإضافة منتجات للبدء</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {cart.map((item) => (
              <div
                key={item.id}
                className="bg-gray-50 rounded-lg p-3 border border-gray-200"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="text-sm text-gray-900">{item.name}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {item.price} ريال × {item.quantity}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onRemoveItem(item.id)}
                    className="h-7 w-7 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                      className="h-7 w-7 p-0 border-gray-300"
                    >
                      <Minus className="w-3 h-3" />
                    </Button>
                    
                    <span className="text-sm text-gray-900 w-8 text-center">
                      {item.quantity}
                    </span>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="h-7 w-7 p-0 border-gray-300"
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>

                  <span className="text-sm text-orange-600">
                    {(item.price * item.quantity).toFixed(2)} ريال
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      <div className="p-6 border-t border-gray-200 space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">المجموع الفرعي</span>
            <span className="text-gray-900">{total.toFixed(2)} ريال</span>
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <span className="text-lg text-gray-900">الإجمالي</span>
            <span className="text-2xl text-orange-600">{total.toFixed(2)} ريال</span>
          </div>
        </div>

        <Button
          onClick={handleCheckout}
          disabled={cart.length === 0}
          className="w-full h-12 bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <CreditCard className="w-5 h-5 ml-2" />
          إتمام البيع
        </Button>
      </div>
    </div>
  );
}