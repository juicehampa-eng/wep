import { useState } from 'react';
import { CupSoda, Lock, User as UserIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { authenticateUser, setCurrentUser } from '../utils/auth';
import { User } from '../types';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = authenticateUser(username, password);
    
    if (user) {
      setCurrentUser(user);
      onLogin(user);
    } else {
      setError('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Logo */}
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-br from-orange-500 to-yellow-500 p-4 rounded-2xl">
              <CupSoda className="w-12 h-12 text-white" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl text-center text-gray-900 mb-2">
            نظام نقاط البيع
          </h1>
          <p className="text-center text-sm text-gray-500 mb-8">
            متجر العصائر - تسجيل الدخول
          </p>

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username">اسم المستخدم</Label>
              <div className="relative mt-1">
                <UserIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="pr-10"
                  placeholder="أدخل اسم المستخدم"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password">كلمة المرور</Label>
              <div className="relative mt-1">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pr-10"
                  placeholder="أدخل كلمة المرور"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white"
            >
              تسجيل الدخول
            </Button>
          </form>

          {/* Demo Accounts */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-center text-gray-500 mb-3">حسابات تجريبية:</p>
            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between items-center bg-gray-50 rounded-lg px-3 py-2">
                <span>مدير (كامل الصلاحيات)</span>
                <code className="bg-gray-200 px-2 py-1 rounded">admin / 10</code>
              </div>
              <div className="flex justify-between items-center bg-gray-50 rounded-lg px-3 py-2">
                <span>كاتب (بيع وعرض)</span>
                <code className="bg-gray-200 px-2 py-1 rounded">writer / writer</code>
              </div>
              <div className="flex justify-between items-center bg-gray-50 rounded-lg px-3 py-2">
                <span>مستخدم (بيع فقط)</span>
                <code className="bg-gray-200 px-2 py-1 rounded">user / 22</code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
