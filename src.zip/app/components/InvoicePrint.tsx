import { Sale } from '../types';
import { CupSoda } from 'lucide-react';

interface InvoicePrintProps {
  sale: Sale;
}

const paymentMethodNames = {
  cash: 'نقدي',
  card: 'بطاقة',
  wallet: 'محفظة إلكترونية',
};

export function InvoicePrint({ sale }: InvoicePrintProps) {
  const date = new Date(sale.timestamp);

  return (
    <div className="hidden print:block">
      <div className="max-w-[80mm] mx-auto p-4 font-mono text-sm">
        {/* Header */}
        <div className="text-center mb-4 pb-4 border-b-2 border-dashed border-gray-400">
          <div className="flex justify-center mb-2">
            <CupSoda className="w-8 h-8" />
          </div>
          <h1 className="text-lg mb-1">متجر العصائر</h1>
          <p className="text-xs text-gray-600">فاتورة بيع</p>
        </div>

        {/* Invoice Info */}
        <div className="mb-4 pb-4 border-b border-dashed border-gray-300 text-xs space-y-1">
          <div className="flex justify-between">
            <span>رقم الفاتورة:</span>
            <span className="font-bold">{sale.invoiceNumber}</span>
          </div>
          <div className="flex justify-between">
            <span>التاريخ:</span>
            <span>{date.toLocaleDateString('ar-SA')}</span>
          </div>
          <div className="flex justify-between">
            <span>الوقت:</span>
            <span>{date.toLocaleTimeString('ar-SA')}</span>
          </div>
          <div className="flex justify-between">
            <span>الكاشير:</span>
            <span>{sale.userName}</span>
          </div>
          <div className="flex justify-between">
            <span>طريقة الدفع:</span>
            <span>{paymentMethodNames[sale.paymentMethod]}</span>
          </div>
        </div>

        {/* Items */}
        <div className="mb-4 pb-4 border-b-2 border-dashed border-gray-400">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="text-right pb-2">الصنف</th>
                <th className="text-center pb-2">الكمية</th>
                <th className="text-right pb-2">السعر</th>
                <th className="text-right pb-2">الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              {sale.items.map((item, index) => (
                <tr key={index} className="border-b border-gray-200">
                  <td className="py-2 text-right">{item.name}</td>
                  <td className="py-2 text-center">{item.quantity}</td>
                  <td className="py-2 text-right">{item.price.toFixed(2)}</td>
                  <td className="py-2 text-right">
                    {(item.price * item.quantity).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Total */}
        <div className="mb-4 pb-4 border-b-2 border-dashed border-gray-400">
          <div className="flex justify-between text-base mb-1">
            <span>الإجمالي:</span>
            <span className="font-bold">{sale.total.toFixed(2)} ريال</span>
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>عدد الأصناف:</span>
            <span>{sale.items.reduce((sum, item) => sum + item.quantity, 0)}</span>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-gray-600 space-y-1">
          <p>شكراً لزيارتكم</p>
          <p>نتمنى لكم يوماً سعيداً</p>
          <p className="mt-2 text-[10px]">* فاتورة إلكترونية *</p>
        </div>
      </div>
    </div>
  );
}

export function printInvoice(sale: Sale) {
  // Create temporary container
  const printContainer = document.createElement('div');
  printContainer.innerHTML = `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <title>فاتورة ${sale.invoiceNumber}</title>
      <style>
        @media print {
          body { margin: 0; padding: 0; }
          @page { margin: 0; size: 80mm auto; }
        }
        body {
          font-family: 'Courier New', monospace;
          max-width: 80mm;
          margin: 0 auto;
          padding: 10px;
          font-size: 12px;
        }
        .text-center { text-align: center; }
        .mb-4 { margin-bottom: 16px; }
        .pb-4 { padding-bottom: 16px; }
        .border-b-2 { border-bottom: 2px dashed #999; }
        .border-b { border-bottom: 1px dashed #ccc; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 4px; text-align: right; }
        th { border-bottom: 1px solid #999; }
        td { border-bottom: 1px solid #eee; }
        .text-xs { font-size: 10px; }
        .font-bold { font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="text-center mb-4 pb-4 border-b-2">
        <h1>متجر العصائر</h1>
        <p class="text-xs">فاتورة بيع</p>
      </div>
      
      <div class="mb-4 pb-4 border-b text-xs">
        <div>رقم الفاتورة: <span class="font-bold">${sale.invoiceNumber}</span></div>
        <div>التاريخ: ${new Date(sale.timestamp).toLocaleDateString('ar-SA')}</div>
        <div>الوقت: ${new Date(sale.timestamp).toLocaleTimeString('ar-SA')}</div>
        <div>الكاشير: ${sale.userName}</div>
        <div>طريقة الدفع: ${paymentMethodNames[sale.paymentMethod]}</div>
      </div>
      
      <div class="mb-4 pb-4 border-b-2">
        <table class="text-xs">
          <thead>
            <tr>
              <th>الصنف</th>
              <th>الكمية</th>
              <th>السعر</th>
              <th>الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            ${sale.items.map(item => `
              <tr>
                <td>${item.name}</td>
                <td style="text-align: center">${item.quantity}</td>
                <td>${item.price.toFixed(2)}</td>
                <td>${(item.price * item.quantity).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      
      <div class="mb-4 pb-4 border-b-2">
        <div style="font-size: 14px; margin-bottom: 8px;">
          <strong>الإجمالي: ${sale.total.toFixed(2)} ريال</strong>
        </div>
        <div class="text-xs">
          عدد الأصناف: ${sale.items.reduce((sum, item) => sum + item.quantity, 0)}
        </div>
      </div>
      
      <div class="text-center text-xs">
        <p>شكراً لزيارتكم</p>
        <p>نتمنى لكم يوماً سعيداً</p>
        <p style="margin-top: 8px; font-size: 10px">* فاتورة إلكترونية *</p>
      </div>
    </body>
    </html>
  `;

  // Open print window
  const printWindow = window.open('', '', 'width=300,height=600');
  if (printWindow) {
    printWindow.document.write(printContainer.innerHTML);
    printWindow.document.close();
    
    // Wait for content to load then print
    printWindow.onload = () => {
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 250);
    };
  }
}
