export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type UserRole = 'user' | 'writer' | 'admin';

export interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  permissions: {
    canViewSales: boolean;
    canMakeSales: boolean;
    canDeleteSales: boolean;
    canManageUsers: boolean;
    canViewReports: boolean;
  };
}

export type PaymentMethod = 'cash' | 'card' | 'wallet';

export interface Sale {
  id: string;
  items: CartItem[];
  total: number;
  paymentMethod: PaymentMethod;
  userId: string;
  userName: string;
  timestamp: number;
  invoiceNumber: string;
}
